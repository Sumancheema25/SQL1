create table test(id int not null primary key, day date not null);

insert into test(id, day) values(1, '2006-10-08');
insert into test(id, day) values(2, '2006-10-08');
insert into test(id, day) values(3, '2006-10-09');

select * from test;
select day, count(*) from test GROUP BY day;
select day, count(*) from test group by day HAVING count(*) > 1;
create table to_delete (day date not null, min_id int not null);

insert into to_delete(day, min_id)
   select day, MIN(id) from test group by day having count(*) > 1;

select * from to_delete;


CREATE TABLE employees
( employee_number int NOT NULL,
  employee_name char(50) NOT NULL,
  salary int)

insert into employees (employee_number,employee_name ,salary) values(1,'Sumit kumar',2500),(2,'Karanjit',2500),(3,'Paramjit',3800);
select *FROM employees;

 select MAX(salary) from employees
WHERE salary <> (select MAX(salary) from employees )



