use MovieBooking

CREATE TABLE CUSTOMERS(
   ID   INT  IDENTITY  NOT NULL,
   NAME VARCHAR (20)     NOT NULL,
   AGE  INT              NOT NULL,
   PRIMARY KEY (ID),
) 
insert into CUSTOMERS values('karan',22)
EXEC SelectAllCustomers;

CREATE TABLE MOVIE(
   Movie_ID   INT  IDENTITY  NOT NULL,
   Movie_Name VARCHAR (20)     NOT NULL,
   PRIMARY KEY (Movie_ID),
) 
insert into MOVIE values('The Dark Knight')
select * from MOVIE

CREATE TABLE BOOKING(
	Booking_ID INT IDENTITY,
	Movie_ID INT,
	Movie_Name VARCHAR(20)  NOT NULL,
	PRIMARY KEY (Booking_ID),
	Foreign key (Movie_ID) REFERENCES MOVIE(Movie_ID)
);
select * from  MOVIE

Alter table booking
add foreign key (Movie_ID) references customers(ID)




